package com.educationloan.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.educationloan.demo.model.LoanApplicationModel;
import com.educationloan.demo.model.UserModel;
import com.educationloan.demo.service.LoanService;


@RestController
public class LoanController {

	@Autowired
	LoanService ls;
	@GetMapping("/getUser")
	public List<UserModel> getProfile(){
		return ls.getUser();
	}
	@PostMapping("/postUser")
	public UserModel postProfile(@RequestBody UserModel a) {
		return ls.postUser(a);
	}
	@PutMapping("/putUser")
	public UserModel updateProfile(@RequestBody UserModel b)
	{
		
		return ls.postUser(b);
	}
	@DeleteMapping("/deleteid/{id}")
	public String deleteProfile(@PathVariable int id)
	{
		 return ls.deleteUser(id);
	}
	@GetMapping("/getAdmin")
	public List<LoanApplicationModel> getProfile1(){
		return ls.getUser1();
	}
	@PostMapping("/postAdmin")
	public LoanApplicationModel postProfile1(@RequestBody LoanApplicationModel a) {
		return ls.postUser1(a);
	}
	@PutMapping("/putAdmin")
	public LoanApplicationModel updateProfile1(@RequestBody LoanApplicationModel b)
	{
		
		return ls.postUser1(b);
	}
	@DeleteMapping("/deleteLoanid/{loanId}")
	public String deleteProfile1(@PathVariable int loanId)
	{
		 return ls.deleteUser1(loanId);
	}
}
