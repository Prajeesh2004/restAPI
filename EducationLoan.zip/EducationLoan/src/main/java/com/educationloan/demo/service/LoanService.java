package com.educationloan.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educationloan.demo.model.LoanApplicationModel;
import com.educationloan.demo.model.UserModel;
import com.educationloan.demo.repository.AdminRepository;
import com.educationloan.demo.repository.LoanApplicationRepository;
import com.educationloan.demo.repository.LoginRepository;
import com.educationloan.demo.repository.UserRepository;
@Service
public class LoanService {

	@Autowired
	AdminRepository ar;
	@Autowired
	LoanApplicationRepository lar;
	@Autowired
	LoginRepository lr;
	@Autowired
	UserRepository ur;
	public List<UserModel> getUser() {
		
		return ur.findAll();
	}
	public UserModel postUser(UserModel a) {
		
		return ur.save(a);
	}
	public UserModel updateUser(UserModel b) {
		
		return ur.save(b);
	}
	public String deleteUser(int id) {
		ur.deleteById(id);
		return id+" id has been deleted";
	}
public List<LoanApplicationModel> getUser1() {
		
		return lar.findAll();
	}
	public LoanApplicationModel postUser1(LoanApplicationModel a) {
		
		return lar.save(a);
	}
	public LoanApplicationModel updateUser1(LoanApplicationModel b) {
		
		return lar.save(b);
	}
	public String deleteUser1(int loanId) {
		lar.deleteById(loanId);
		return loanId+" id has been deleted";
	}
}
