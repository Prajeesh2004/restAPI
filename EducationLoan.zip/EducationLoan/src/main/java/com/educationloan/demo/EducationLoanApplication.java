package com.educationloan.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationLoanApplication.class, args);
	}

}
