package com.educationloan.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class LoanApplicationModel {
	@Id
	private int loanId;
	private String loanType;
	private String applicantName;
	private String applicantAddress;
	private String applicantEmail;
	private String applicantAadhaar;
	private String applicantPan;
	private String applicantSalary;
	private String loanAmountRequired;
	private String loanPaymentMonth;
	@Override
	public String toString() {
		return "LoanApplicationModel [loanId=" + loanId + ", loanType=" + loanType + ", applicantName=" + applicantName
				+ ", applicantAddress=" + applicantAddress + ", applicantEmail=" + applicantEmail
				+ ", applicantAadhaar=" + applicantAadhaar + ", applicantPan=" + applicantPan + ", applicantSalary="
				+ applicantSalary + ", loanAmountRequired=" + loanAmountRequired + ", loanPaymentMonth="
				+ loanPaymentMonth + "]";
	}
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public String getApplicantAddress() {
		return applicantAddress;
	}
	public void setApplicantAddress(String applicantAddress) {
		this.applicantAddress = applicantAddress;
	}
	public String getApplicantEmail() {
		return applicantEmail;
	}
	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}
	public String getApplicantAadhaar() {
		return applicantAadhaar;
	}
	public void setApplicantAadhaar(String applicantAadhaar) {
		this.applicantAadhaar = applicantAadhaar;
	}
	public String getApplicantPan() {
		return applicantPan;
	}
	public void setApplicantPan(String applicantPan) {
		this.applicantPan = applicantPan;
	}
	public String getApplicantSalary() {
		return applicantSalary;
	}
	public void setApplicantSalary(String applicantSalary) {
		this.applicantSalary = applicantSalary;
	}
	public String getLoanAmountRequired() {
		return loanAmountRequired;
	}
	public void setLoanAmountRequired(String loanAmountRequired) {
		this.loanAmountRequired = loanAmountRequired;
	}
	public String getLoanPaymentMonth() {
		return loanPaymentMonth;
	}
	public void setLoanPaymentMonth(String loanPaymentMonth) {
		this.loanPaymentMonth = loanPaymentMonth;
	}
}
