package com.educationloan.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationLoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
