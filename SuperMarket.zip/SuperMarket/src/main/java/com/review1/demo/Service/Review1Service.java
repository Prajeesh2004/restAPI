package com.review1.demo.Service;


import java.util.List;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.review1.demo.model.CustomerDetails;
import com.review1.demo.model.Supermarket;

import jakarta.transaction.Transactional;

//import com.review.demo.model.Employee;
import com.review1.demo.Repository.*;

@Service
public class Review1Service {
	@Autowired
	Review1Repository r;
	@Autowired
	CustomerRep c;
	public List<Supermarket> getAllReview1Models()
	{
		return r.findAll();
		
	}
	public Supermarket saveReview1Model (Supermarket s)
	{
		
		return r.save(s);
		
	}
	public String deleteReview1Model(int id)
	{
		r.deleteById(id);
		return "Id has been deleted";
	}
	public Supermarket getReview1Model(int id)
	{
		return r.findById(id).get();
	}
	public List<Supermarket> sortdetails(String id) {
		
		 return r.findAll(Sort.by(id));
	}

	public List<Supermarket> getpagingDetails1(@PathVariable int offset, @PathVariable int pagesize) 
	{
		Page <Supermarket> page=r.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Supermarket> getdetailscustomer(String cost) {
		 return r.findAll(Sort.by(cost).ascending());
	}
	public List<Supermarket> details(String cost) {
		 return r.findAll(Sort.by(cost).descending());
	}
	public List<Supermarket> getcustdetails(@PathVariable int offset,@PathVariable int pagesize) {
		Page <Supermarket> page=r.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Supermarket> getcustdetails1(int offset, int pagesize, String field) {
		PageRequest paging=PageRequest.of(offset, pagesize,Sort.by(field));
		Page<Supermarket>page=r.findAll(paging);
		return page.getContent() ;
	}
	public List<Supermarket> fetchEmployeeByNamePrefix(String prefix)
	  {
		  return r.findByNameStartingWith(prefix);
	  }
	public List<Supermarket> fetchEmployeeByNameSuffix(String suffix)
	{
		return r.findByNameEndingWith(suffix);
	}
	public List<Supermarket> getEmployeesByDept(String cost,String name)
	  {
		  return r.getEmployeesByDept(cost, name);
	  }
	public List<Supermarket> getDataByQuery(String name, String product_name) {
		return r.getSupermarketByPPosition(name, product_name);
	}
	public List<Supermarket> getDataByPName(String name, String product_name) {
		return r.getSupermarketByPName(name, product_name);
	}
	@Transactional
	public int deleteDataQuery(String name) {
		 return r.deleteSupermarketByName(name);
	}
	@Transactional
	public int updateSupermarket(String name, String cost, String id) {
		return r.updateSupermarket(name,cost,id);
	}
	public List<Supermarket> getDataSupermarket(String cost) {
		return r.getDataSupermarket(cost);
	}
	public List<CustomerDetails> getDataCustomer() {
		return c.findAll();
	}

	public CustomerDetails saveDataCustomer(CustomerDetails data) {
		return c.save(data);
	}


	
}