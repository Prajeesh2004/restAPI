package com.review1.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.review1.demo.Service.LoginpageService;
import com.review1.demo.model.LoginpageModel;




@RestController
public class LoginpageController {
	@Autowired
	LoginpageService usrService;
	@PostMapping("/addUser")
	public  LoginpageModel getdata (@RequestBody LoginpageModel u)
	{
		return usrService.saveData(u);
	}
	@PostMapping("/checkLogin")
	public String validateUser(@RequestBody LoginpageModel u)
	{
		System.out.println(u.getUsername());
		return usrService.validateUser(u.getUsername(),u.getPassword());
	}
}