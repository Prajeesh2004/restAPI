package com.review1.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.review1.demo.model.LoginpageModel;

@Repository
public interface LoginpageRepository extends JpaRepository <LoginpageModel,Integer>{
	

	
	LoginpageModel findByUsername(String username);

}