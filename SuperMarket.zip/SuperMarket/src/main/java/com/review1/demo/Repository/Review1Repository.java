package com.review1.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

//import com.review.demo.model.Employee;
import com.review1.demo.model.Supermarket;

public interface Review1Repository extends JpaRepository<Supermarket,Integer> {
	
	//positionalParameter
			@Query("select s from Supermarket s where s.name=?1 and s.product_name=?2")
			List<Supermarket> getSupermarketByPPosition(String name,String product_name);
			
			//nameParameter
			@Query("select s from Supermarket s where s.name=:name and s.product_name=:product_name")
			List<Supermarket> getSupermarketByPName(String name,String product_name);

			@Modifying
			@Query("delete from Supermarket s where s.name=?1")
			public int deleteSupermarketByName(String name);
			
			@Modifying
			@Query("update Supermarket s set s.name=?1,s.cost=?2 where s.id=?3")
			public int updateSupermarket(String name,String cost,String id);
			
			@Query(value="select * from purchase s where s.cost=?1", nativeQuery=true)
			public List<Supermarket> getDataSupermarket(String cost);
	
			List<Supermarket> findByNameStartingWith(String prefix);
			List<Supermarket> findByNameEndingWith(String suffix);
//			List<Supermarket> findByDept(String cost);
			@Query("select s from Supermarket s where s.cost=?1 and s.name=?2" )
			public List<Supermarket> getEmployeesByDept(String cost,String name);

}